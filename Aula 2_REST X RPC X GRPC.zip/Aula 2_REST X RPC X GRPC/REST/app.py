# Importa a classe Flask da biblioteca flask
from flask import Flask

# Cria a aplicação Flask
# __name__ indica o nome do módulo atual e principal
app = Flask(__name__)

# Define uma rota (URL)
# "/" é a rota principal do site (http://localhost:5000/)
@app.route("/")
def home():
    # Retorna uma resposta simples em texto
    return "Olá! Meu primeiro servidor Flask está funcionando "

# inicializa o servidor
app.run(debug=True)

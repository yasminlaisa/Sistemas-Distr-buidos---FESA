from flask import Flask, render_template, request

app = Flask(__name__)

# Rota principal que exibe a página HTML
@app.route("/")
def index():
    # Renderiza o arquivo calculadora.html
    return render_template("calculadora.html")

# Rota que recebe os dados do formulário
@app.route("/calcular", methods=["POST"])
def calcular():
    num1 = float(request.form["num1"])
    num2 = float(request.form["num2"])
    operacao = request.form["operacao"]

    if operacao == "somar":
        resultado = num1 + num2
    elif operacao == "subtrair":
        resultado = num1 - num2
    elif operacao == "multiplicar":
        resultado = num1 * num2
    elif operacao == "dividir":
        if num2 == 0:
            resultado = "Erro: divisão por zero"
        else:
            resultado = num1 / num2

    # Retorna o HTML novamente, agora com o resultado
    return render_template("calculadora.html", resultado=resultado)

app.run(debug=True)

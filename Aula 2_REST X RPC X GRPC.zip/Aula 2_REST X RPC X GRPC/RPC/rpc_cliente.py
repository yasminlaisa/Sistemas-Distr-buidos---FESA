from xmlrpc.client import ServerProxy         # Cliente RPC (biblioteca padrão)

if __name__ == "__main__":                    
    proxy = ServerProxy("http://127.0.0.1:8000", allow_none=True)  # Cria proxy (stub) do servidor

    print("Chamando add(2, 3) remotamente...")  # Log
    r1 = proxy.add(2, 3)                        # RPC: parece chamada local, mas executa no servidor
    print("Resultado:", r1)                     # Mostra resultado

    print("Chamando mul(6, 7) remotamente...")  
    r2 = proxy.mul(6, 7)                        # Outra chamada remota
    print("Resultado:", r2)                     # Mostra resultado

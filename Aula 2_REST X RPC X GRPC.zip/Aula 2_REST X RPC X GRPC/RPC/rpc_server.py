# RPC é processo chamando processo
#RPC não tem rotas, só métodos
from xmlrpc.server import SimpleXMLRPCServer  

def add(a, b):                                
    return a + b                              

def mul(a, b):                                
    return a * b                              

if __name__ == "__main__":                    # Ponto de entrada do programa
    server = SimpleXMLRPCServer(("127.0.0.1", 8000), allow_none=True)  # Cria servidor na porta 8000
    server.register_function(add, "add")      # Registra a função como chamada remota "add"
    server.register_function(mul, "mul")      # Registra a função como chamada remota "mul"
    print("Servidor RPC rodando em http://127.0.0.1:8000")            # Log
    server.serve_forever()                    # Mantém o servidor ativo aguardando chamadas

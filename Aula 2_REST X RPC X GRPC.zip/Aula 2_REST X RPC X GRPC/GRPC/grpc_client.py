import grpc                                               # Biblioteca gRPC

import calc_pb2                                           # Mensagens geradas
import calc_pb2_grpc                                      # Stub gerado (proxy do cliente)

def main():
    channel = grpc.insecure_channel("127.0.0.1:50051")    # Cria canal para o servidor (sem TLS)
    stub = calc_pb2_grpc.CalculatorStub(channel)          # Cria o “stub/proxy” do serviço remoto

    req = calc_pb2.BinaryOpRequest(a=6, b=7)              # Monta a requisição (mensagem protobuf)

    r1 = stub.Add(req)                                    # RPC síncrono: chama Add no servidor
    print("Add(6,7) =", r1.result)                        # Exibe resultado

    r2 = stub.Mul(req)                                    # RPC síncrono: chama Mul no servidor
    print("Mul(6,7) =", r2.result)                        # Exibe resultado

if __name__ == "__main__":
    main()                                                # Executa cliente

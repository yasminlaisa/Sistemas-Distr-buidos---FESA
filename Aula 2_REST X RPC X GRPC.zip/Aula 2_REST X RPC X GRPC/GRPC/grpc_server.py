import time                                              # Para simular algum processamento
from concurrent import futures                            # Thread pool para o servidor gRPC
import grpc                                               # Biblioteca gRPC

import calc_pb2                                           # Classes das mensagens (geradas do .proto)
import calc_pb2_grpc                                      # Classes do serviço (geradas do .proto)

class CalculatorService(calc_pb2_grpc.CalculatorServicer):  # Implementa a “interface” do serviço
    def Add(self, request, context):                      # Implementa o RPC Add
        result = request.a + request.b                    # Executa a soma no servidor
        return calc_pb2.OpReply(result=result)            # Retorna a resposta (mensagem protobuf)

    def Mul(self, request, context):                      # Implementa o RPC Mul
        result = request.a * request.b                    # Executa a multiplicação no servidor
        return calc_pb2.OpReply(result=result)            # Retorna a resposta

def serve():                                              # Função para subir o servidor
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))  # Cria servidor com pool de threads
    calc_pb2_grpc.add_CalculatorServicer_to_server(CalculatorService(), server)  # Registra serviço
    server.add_insecure_port("127.0.0.1:50051")           # Define endereço/porta (inseguro, sem TLS, para laboratório)
    server.start()                                        # Inicia o servidor
    print("Servidor gRPC rodando em 127.0.0.1:50051")     # Log
    try:
        while True:                                       # Mantém o processo vivo
            time.sleep(3600)                              # Dorme para não ocupar CPU
    except KeyboardInterrupt:
        server.stop(0)                                    # Para o servidor imediatamente

if __name__ == "__main__":
    serve()                                               # Executa servidor
